<?php
/**
 * @version     1.2.0
 * @package     com_jm_deluxe_layer_slideshow
 * @copyright   Copyright (C) 2013 - joomlaman.com.
 * @license     http://www.gnu.org/copyleft/lgpl.html
 * @author      JoomlaMan <support@joomlaman.com> - http://joomlaman.com
 */
// No direct access
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/jm_slider_revolution.php';
$isJoomla3 = Jm_slider_revolutionHelper::isJoomla3();
//include frameword files
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/framework/include_framework.php';
//include bases
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/framework/base.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/framework/elements_base.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/framework/base_admin.class.php';
//require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/framework/base_front.class.php';
//include product files
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_settings_product.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_globals.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_operations.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_slider.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_output.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_slide.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_params.class.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/fonts.class.php';
/**
 * include the unitejoomla library
 */
//require_once JPATH_COMPONENT_ADMINISTRATOR.'/classes/revslider_admin.php';
jimport('joomla.application.component.view');
jimport('joomla.application.component.controller');
if($isJoomla3){ //joomla 3.x
		class RSliderView extends JViewLegacy{};
		class RSliderController extends JControllerLegacy{};

}else{ //joomla 2.5
		class RSliderView extends JView{};
		class RSliderController extends JController{};
}
	
?>