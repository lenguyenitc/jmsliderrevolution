DROP TABLE IF EXISTS `#__revslider_sliders`;
DROP TABLE IF EXISTS `#__revslider_slides`;

